<?php 

$conn = mysqli_connect('localhost', 'root', '', 'm_task');

if(!$conn){
    echo "Database Not Connect";
}
?>