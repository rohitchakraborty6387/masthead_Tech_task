<?php 
include_once './db.php';

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $pass = $_POST['pass'];

    $sql = "select * from users where email = '$email'";
    $row = mysqli_query($conn, $sql);
    
    while($data = mysqli_fetch_array($row)){
        $hpass = $data['pass'];
        $passmatch = password_verify($pass, $hpass);

        if(in_array($email, $data)){
           if($passmatch){
              session_start();
              $_SESSION['email'] = $email;
              header("Location:dashboard.php");
           }else{
            echo "Please Enter Correct Password";
           }
        }else{
            echo "Please Register First";
        }
    }


}

?>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<link rel="stylesheet" href="style.css">
<!------ Include the above in your HEAD tag ---------->
<html>
  <head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  </head>
<body id="LoginForm">
<div class="container">
    <div class="login-form">
        <div class="main-div">
            <div class="panel">
               
            </div>
    <form id="Login" method="post">        
        <h1>Login Form</h1>

        <div class="form-group">
            <input type="email" name="email" class="form-control" id="inputPassword" placeholder="Enter Your Email">
        </div>

        <div class="form-group">
            <input type="password" name="pass" class="form-control" id="inputPassword" placeholder="Enter Password">
        </div>

        <button type="submit" name="login" class="btn btn-primary">Login</button>

    </form>
    <a href="index.php">Register</a>
    </div>
</div></div></div>


</body>
</html>
