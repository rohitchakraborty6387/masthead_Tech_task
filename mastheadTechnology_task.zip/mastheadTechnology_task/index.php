<?php 
include_once './db.php';

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = password_hash($_POST['pass'] , PASSWORD_DEFAULT);

    $sql = "INSERT INTO users(`name`, `email`,`pass`) values('$name', '$email', '$pass')";
    $ins = mysqli_query($conn, $sql);

    if($ins == true){
        echo "<script>alert('Register Successfully')</script>";
        header('Location:login.php');
    }else{
        echo "<script>alert('Data Not Insert')</script>";
    }

}

?>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<link rel="stylesheet" href="style.css">
<!------ Include the above in your HEAD tag ---------->
<html>
  <head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  </head>
<body id="LoginForm">
<div class="container">
    <div class="login-form">
        <div class="main-div">
            <div class="panel">
               
            </div>
    <form id="Login" method="post">        
        <h1>Register Form</h1>
        <div class="form-group">
            <input type="text" name="name" class="form-control" id="inputEmail" placeholder="Email Your Name">
        </div>

        <div class="form-group">
            <input type="email" name="email" class="form-control" id="inputPassword" placeholder="Enter Your Email">
        </div>

        <div class="form-group">
            <input type="password" name="pass" class="form-control" id="inputPassword" placeholder="Enter Password">
        </div>

        <button type="submit" name="register" class="btn btn-primary">Register</button>

    </form>
    </div>
</div></div></div>


</body>
</html>
